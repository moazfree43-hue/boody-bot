import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { commandRegistry } from "../../handlers/commandRegistry";
import { sendButtonMessage, navButtons } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";
import { formatUptime } from "../../utils/uptime";
import { FOOTER_DIVIDER } from "../../utils/theme";

/**
 * قسم ".بوت" — معلومات تفصيلية عن البوت نفسه، منفصل عن ".menu" (القائمة
 * الرئيسية) بعد ما كان اسمًا بديلًا لها بالغلط. صار له الآن صورة هوية
 * خاصة (assets/sections/bot.png) وقائمة معلومات مستقلة، حسب ما طُلب.
 */
const command: Command = {
  name: "بوت",
  aliases: ["botinfo", "معلومات_البوت"],
  category: "بوت",
  description: "معلومات تفصيلية عن البوت (الإصدار، المكتبة، المطور، الأوامر...)",
  permission: "all",
  execute: async (ctx) => {
    const sentAt = Number(ctx.msg.messageTimestamp || 0) * 1000;
    const ping = sentAt ? Math.max(0, Date.now() - sentAt) : 0;
    const sectionsCount = new Set(commandRegistry.getAll().map((c) => c.category)).size;

    const text =
      `${FOOTER_DIVIDER}\n      🤖 *${CONFIG.BOT_NAME}* 🤖\n${FOOTER_DIVIDER}\n\n` +
      `  الاسم ﹘ ${CONFIG.BOT_NAME}\n` +
      `  الإصدار ﹘ v${CONFIG.BOT_VERSION}\n` +
      `  لغة البرمجة ﹘ TypeScript (Node.js)\n` +
      `  المكتبة ﹘ Baileys (@whiskeysockets/baileys)\n` +
      `  المطور ﹘ ${CONFIG.OWNER_NAME}\n` +
      `  الوصف ﹘ بوت واتساب احترافي بهوية أنمي، فعاليات جماعية، حماية، ونظام بنك ونقاط\n\n` +
      `  🧩 عدد الأوامر ﹘ ${commandRegistry.count()} أمر\n` +
      `  📂 عدد الأقسام ﹘ ${sectionsCount} أقسام\n` +
      `  ⏳ Uptime ﹘ ${formatUptime()}\n` +
      `  ⚡ Ping ﹘ ${ping}ms\n\n` +
      `  ✨ أهم الميزات:\n` +
      `  • فعاليات جماعية (تخمين نصي وصور)\n` +
      `  • نظام حماية (روابط/سبام)\n` +
      `  • نظام بنك ونقاط\n` +
      `  • تحميل فيديوهات تيك توك/انستقرام\n` +
      `  • ردود تلقائية وتفاعل بالإيموجي\n` +
      `${FOOTER_DIVIDER}`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("bot") || undefined,
      quickButtons: navButtons(),
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
