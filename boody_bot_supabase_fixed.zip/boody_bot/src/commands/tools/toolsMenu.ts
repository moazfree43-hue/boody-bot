import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, sectionButton, navButtons, buildSingleSelectButton } from "../../utils/interactive";
import { TOOLS_EXTRA_ROWS } from "../../utils/menuRows";
import { FOOTER_DIVIDER } from "../../utils/theme";
import { getSectionImageBuffer } from "../../utils/media";

const command: Command = {
  name: "ادوات",
  aliases: ["tools", "أدوات"],
  category: "ادوات",
  description: "عرض قائمة الأدوات المتاحة",
  permission: "all",
  execute: async (ctx) => {
    const text =
      `ـ✦ ──────── ✦ـ\n   ـ.*⋆⊱༻𖥸༺⊰⋆* ـ \n      🛠️ *الأدوات* 🛠️\nـ✦ ──────── ✦ـ\n\n` +
      `🔱*تحويل الوسائط:*\n` +
      `  *🔆${CONFIG.PREFIX}ملصق*\n` +
      `  *🔆${CONFIG.PREFIX}ملصقات <بحث>* (حزمة ٨ ملصقات)\n` +
      `  *☢️${CONFIG.PREFIX}صوره*\n` +
      `  *☣️${CONFIG.PREFIX}صوت <نص>*\n` +
      `ـ.*⋆⊱༻𖥸༺⊰⋆* ـ\n` +
      `💭*بروفايل شخص:*\n` +
      `  *🎫${CONFIG.PREFIX}بروفايل @شخص*\n` +
      `  *🎫${CONFIG.PREFIX}بروفايل_تعديل*\n` +
      `  *🎫${CONFIG.PREFIX}ترحيب @شخص [نص]*\n` +
      `  *🎫${CONFIG.PREFIX}استمار*\n\n` +
      `ـ(✿ʘ‿ʘ)爻(ʘ‿ʘ✿)ـ\n` +
      `🎬*تحميل:*\n` +
      `  *🎻${CONFIG.PREFIX}تحميل <رابط>*\n` +
      `  *🎻${CONFIG.PREFIX}تحميل_صوت <رابط>*\n\n` +
      `﹌﹌﹌﹌﹌﹌﹌﹌\n` +
      `︵‿︵‿︵‿︵‿︵‿︵\n` +
      `🆕 *تصاميم:*\n` +
      `  *➿${CONFIG.PREFIX}ايديت <نص>*\n` +
      `  *➿${CONFIG.PREFIX}اغنيه <اسم>*\n` +
      `ـ✦────🏯────✦ـ\n` +
      `🌡️ *الطقس:*\n` +
      `  *☀${CONFIG.PREFIX}حراره <دولة>*\n\n` +
      `${FOOTER_DIVIDER}\n` +
      `💡 كل هذي تحتاج نص/رابط/رد فتبقى كتابية، والبنك له زر جاهز تحت 👇\n` +
      `📥 زر "تحميل وتحويلات": تيك، يوتيوب، ميديا، كلمات، لصوت، لفيديو، لرابط، عزل الصوت وغيرها`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("tools") || undefined,
      extraButtons: [buildSingleSelectButton("📥 تحميل وتحويلات", "أدوات التحميل والوسائط", TOOLS_EXTRA_ROWS)],
      quickButtons: [sectionButton("بنك", "🏦 بنك"), ...navButtons()],
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
