import { Command } from "../../handlers/types";
import { getGroupSettings } from "../../database/db";
import { digitsOnly, resolveRealPhoneJid, parseManualPhoneNumber, jidToMention } from "../../utils/helpers";
import { sendButtonMessage, buildCopyCodeButton } from "../../utils/interactive";
import { requestInstallCode } from "../../handlers/subBotManager";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";

/**
 * ============================================================================
 * .تنصيب — يربط رقم المستخدم كـ"جهاز مرتبط" ليشتغل عنده بوت فرعي كامل
 * ============================================================================
 * لا يعمل تلقائيًا بأي مجموعة أبدًا — لازم المطور يفعّله يدويًا بكل مجموعة
 * تحديدًا عبر ".تفعيل_تنصيب" (راجع src/commands/owner/enableInstall.ts).
 *
 * لا يعرض رقم المستخدم إطلاقًا داخل الرسالة (فقط منشن + كود اقتران).
 * ============================================================================
 */
const command: Command = {
  name: "تنصيب",
  category: "تنصيب",
  description: "يربط رقمك كجهاز مرتبط ليشتغل عندك بوت فرعي كامل (يحتاج تفعيل من المطور أولًا بهذي المجموعة)",
  permission: "all",
  groupOnly: true,
  requireBotAdmin: false,
  execute: async (ctx) => {
    // 🆕 (طلب صريح: "لا تسمح لأمر تنصيب يشتغل في أي بوت غير رئيسي") —
    // فقط البوت الرئيسي يقدر ينصّب بوتات فرعية جديدة. بوت فرعي منصّب
    // أصلًا ما يقدر يستخدم نفس الأمر لينصّب بوتات إضافية.
    if (ctx.isSubBot) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "🚫 هذا الأمر خاص بالبوت الرئيسي فقط، غير متاح هنا.",
      });
      return;
    }

    const settings = getGroupSettings(ctx.chatId);
    if (!settings.installEnabled) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `⚠️ ميزة التنصيب غير مفعّلة بهذي المجموعة.\n` +
            `على المطور تفعيلها أولًا بأمر: ${CONFIG.PREFIX}تفعيل_تنصيب`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    // 🔧 إصلاح Username/@lid: لا نخمّن رقم الهاتف أبدًا من معرّف مؤقت.
    // نحاول أولًا نجيب رقم الهاتف الحقيقي الموثوق من بيانات المجموعة
    // (resolveRealPhoneJid لا ترجع إلا رقمًا حقيقيًا فعليًا، وإلا null
    // صراحة — بعكس resolveGroupJid العامة المستخدمة بأماكن أخرى بالمشروع
    // واللي قد ترجع معرّف @lid كـfallback، وهو مناسب هناك لكن غير مقبول
    // هنا). لو تعذّر، نطلب من المستخدم يكتب رقمه يدويًا صراحة.
    const resolvedJid = resolveRealPhoneJid(ctx.senderJid, ctx.metadata);
    let phone: string | null = resolvedJid ? digitsOnly(resolvedJid) : null;

    if (!phone) {
      const manualInput = ctx.text.trim(); // كل شي بعد ".تنصيب" كما كتبه المستخدم
      if (!manualInput) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          {
            text:
              `⚠️ ما قدرنا نتعرّف تلقائيًا على رقمك الحقيقي (يبدو إنك تظهر بمعرّف مؤقت/Username وليس رقم هاتف).\n\n` +
              `اكتب رقمك يدويًا بهذي الصيغة:\n` +
              `${CONFIG.PREFIX}تنصيب <رقمك مع رمز الدولة>\n\n` +
              `مثال:\n${CONFIG.PREFIX}تنصيب +44 7453 388374`,
          },
          { quoted: ctx.msg }
        );
        return;
      }

      const parsed = parseManualPhoneNumber(manualInput);
      if (!parsed) {
        await ctx.sock.sendMessage(
          ctx.chatId,
          {
            text:
              `❌ الرقم اللي كتبته غير صالح.\n` +
              `تأكد إنه رقم هاتف صحيح مع رمز الدولة، مثال:\n${CONFIG.PREFIX}تنصيب +44 7453 388374`,
          },
          { quoted: ctx.msg }
        );
        return;
      }
      phone = parsed;
    }

    if (!phone || phone.length < 7) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ تعذّر التعرف على رقمك الحقيقي حاليًا. حاول مرة ثانية بعد قليل." },
        { quoted: ctx.msg }
      );
      return;
    }

    let code: string;
    try {
      const result = await requestInstallCode(phone);
      code = result.code;
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);

      if (message === "ALREADY_ACTIVE") {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "✅ عندك أصلًا بوت فرعي شغّال ومربوط برقمك. ما تحتاج تنصيب من جديد." },
          { quoted: ctx.msg }
        );
        return;
      }
      if (message === "ALREADY_PENDING") {
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: "⏳ فيه كود سابق لسا بانتظار إدخالك — تفقّد الخاص، أو انتظر شوي قبل ما تطلب كود جديد." },
          { quoted: ctx.msg }
        );
        return;
      }
      if (message.startsWith("COOLDOWN:")) {
        const seconds = message.split(":")[1];
        await ctx.sock.sendMessage(
          ctx.chatId,
          { text: `⏳ لازم تنتظر ${seconds} ثانية قبل ما تطلب كود تنصيب جديد لنفس رقمك.` },
          { quoted: ctx.msg }
        );
        return;
      }

      logger.error("فشل طلب كود تنصيب:", err);
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "❌ صار خطأ أثناء توليد كود التنصيب. حاول مرة ثانية بعد قليل." },
        { quoted: ctx.msg }
      );
      return;
    }

    const groupName = ctx.metadata?.subject || "";
    const mention = jidToMention(ctx.senderJid);

    // 🔧 تراجع مهم عن التعديل السابق (بند 6): كنا نرسل الكود على الخاص
    // (رسالة أولى غير مطلوبة لرقم غريب — مو محفوظ عند رقم البوت أصلًا).
    // هذا بالضبط النمط اللي واتساب يعتبره سلوك سبام من حسابات/أجهزة غير
    // رسمية ويحظر الرقم بسببه بسرعة (تأكد فعليًا: "الرقم جالس ينحضر...
    // يرسل لأشخاص من غير جهة اتصالي فيبندني"). الرسالة بالمجموعة نفسها
    // (بعكس ذلك) ليست "تواصل أول" غريب — هي رد داخل محادثة جماعية العضو
    // نفسه طلبه فيها بأمر صريح، فما تعتبر سلوك سبام إطلاقًا.
    // الحل: رجعنا الكود يُرسل بالمجموعة (زي الأصل قبل بند 6)، مع الإبقاء
    // على تنبيه مختصر بعدم مشاركته + إنه ينتهي خلال دقيقة تقريبًا (بدل
    // الشرح الطويل اللي كان مبرَّر بس بسياق رسالة خاصة).
    const text =
      `*『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』*\n` +
      `*${groupName}*\n` +
      `*ـــــــــــــــــــــــʚ﷽ɞــــــــــــــــــــــ*\n` +
      `> 1. ⚜️ادخل واتساب \n` +
      `> 2. ⚜️الجهزه المرتبطه\n` +
      `> 3. ⚜️ربط جهاز \n` +
      `> 4. ⚜️زر تحت اسمه \n` +
      `> (ستخدام رقم الهاتف) \n` +
      `____________ʚ🇵🇸ɞ____________\n` +
      `*🕥ملاحضه:*\n` +
      `*هذه البوتات قد تتسبب بحضر رقمك*\n` +
      `*نحن لسنا مسولن ان تم حضر رقمك في واتساب*\n` +
      `*فانت تفعل هذا بارادتك الخاصه*\n` +
      `*(اننا نسحب مسوليتنا وشكرا لك لسماعنا)*\n` +
      `⚠️ *لا تشارك الكود مع أي أحد — ينتهي خلال دقيقة تقريبًا*\n` +
      `_______________________\n\n` +
      `*🌪 المستخدم ${mention}*\n\n` +
      `*🔡الكود {${code}}*\n\n` +
      `*___________ʚ🇵🇸ɞ____________*\n\n` +
      `*『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』*`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      mentions: [ctx.senderJid],
      extraButtons: [buildCopyCodeButton(code)],
      fallbackNote: "انسخ الكود يدويًا من أعلى وحطه بواتساب ← الأجهزة المرتبطة ← ربط جهاز ← استخدام رقم الهاتف.",
    });
  },
};

export default command;
