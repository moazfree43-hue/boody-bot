import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, sectionButton, navButtons } from "../../utils/interactive";
import { FOOTER_DIVIDER } from "../../utils/theme";

/**
 * قسم "🕸التنصيب" — شرح كيف تعمل الميزة قبل استخدامها (طلب صريح: أول ما
 * تدخل الزر يعطيك معلومات عن كيف يعمل وكيف يشتغل). راجع install.ts لتنفيذ
 * الأمر الفعلي و enableInstall.ts/disableInstall.ts لتفعيل/تعطيل الميزة
 * بمجموعة معينة (المطور فقط).
 */
const command: Command = {
  name: "تنصيب_قائمة",
  aliases: ["قائمة_تنصيب", "installmenu"],
  category: "تنصيب",
  description: "شرح ميزة التنصيب (ربط رقمك ببوت فرعي) قبل استخدام أمر .تنصيب",
  permission: "all",
  execute: async (ctx) => {
    const p = CONFIG.PREFIX;

    const text =
      `${FOOTER_DIVIDER}\n      🕸 *التنصيب* 🕸\n${FOOTER_DIVIDER}\n\n` +
      `*شنو هذي الميزة؟*\n` +
      `تقدر تربط رقمك أنت كـ"جهاز مرتبط" بواتساب، فيشتغل عندك بوت فرعي\n` +
      `كامل بكل الأوامر (ما عدا أوامر المطور).\n\n` +
      `*كيف تشتغل بالضبط؟*\n` +
      `1️⃣ اكتب ${p}تنصيب داخل الكروب (لازم يكون المطور مفعّلها هون أولًا).\n` +
      `2️⃣ يوصلك كود اقتران برسالة بالكروب (يظهر لك بس، ما يظهر رقمك لحد).\n` +
      `3️⃣ افتح واتساب ← الأجهزة المرتبطة ← ربط جهاز ← استخدام رقم الهاتف،\n` +
      `   وحط الكود اللي وصلك.\n` +
      `4️⃣ بمجرد ما يرتبط، توصلك رسالة على الخاص إنه تم التشغيل + نسخة\n` +
      `   احتياطية من جلستك (خلّيها لنفسك، لا ترسلها لأي أحد).\n\n` +
      `${FOOTER_DIVIDER}\n` +
      `*⚠️ ملاحظة مهمة:*\n` +
      `هذي الميزة تعتمد على خاصية "الأجهزة المرتبطة" بواتساب، وقد تتسبب\n` +
      `بحظر مؤقت أو دائم لرقمك من طرف واتساب نفسه. أنت توافق على هذا\n` +
      `الخطر بمحض إرادتك عند استخدام الأمر.\n\n` +
      `🗑️ لإيقاف وحذف بوتك الفرعي اكتب ${p}الغاء_تنصيب\n\n` +
      `👇 او اضغط الزر تحت مباشرة`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      quickButtons: [sectionButton("تنصيب", "🕸 ابدأ التنصيب الآن"), sectionButton("الغاء_تنصيب", "🗑️ إلغاء التنصيب"), ...navButtons()],
      fallbackNote: `اكتب الأمر مباشرة: ${p}تنصيب`,
    });
  },
};

export default command;
