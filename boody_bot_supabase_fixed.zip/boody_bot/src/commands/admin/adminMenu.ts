import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, sectionButton, navButtons, buildSingleSelectButton } from "../../utils/interactive";
import { ADMIN_EXTRA_ROWS } from "../../utils/menuRows";
import { FOOTER_DIVIDER } from "../../utils/theme";
import { getSectionImageBuffer } from "../../utils/media";

const command: Command = {
  name: "مشرفين",
  aliases: ["admin", "ادارة", "إدارة"],
  category: "مشرفين",
  description: "عرض قائمة أوامر المشرفين",
  permission: "all",
  execute: async (ctx) => {
    const text =
      `ـ,,︵୨(ㅇㅅㅇ)୧︵,,ـ\n 👮 *أوامر المشرفين* 👮\n*ـ୨﹌﹌﹌﹌﹌﹌﹌﹌୧ـ*\n` +
      `  *👢 ${CONFIG.PREFIX}طرد @شخص*\n` +
      `  *⚠️ ${CONFIG.PREFIX}انذار @شخص*\n` +
      `  *🕊️ ${CONFIG.PREFIX}اعفاء @شخص <عدد>*\n` +
      `  *🔇 ${CONFIG.PREFIX}كتم @شخص*\n` +
      `  *🔇 ${CONFIG.PREFIX}كتم <دقايق>*\n` +
      `  *🔊 ${CONFIG.PREFIX}فك_الكتم @شخص*\n` +
      `  *🚫 ${CONFIG.PREFIX}حظر @شخص*\n` +
      `  *✅ ${CONFIG.PREFIX}فك_الحظر @شخص*\n` +
      `  *⬆️ ${CONFIG.PREFIX}رفع ادمن @شخص*\n` +
      `  *⬇️ ${CONFIG.PREFIX}تنزيل ادمن @شخص*\n` +
      `  *📢 ${CONFIG.PREFIX}منشن 1*\n` +
      `  *🗑️ ${CONFIG.PREFIX}حذف*\n` +
      `  *📝 ${CONFIG.PREFIX}تغيير_الوصف <نص>*\n` +
      `  *🖼️ ${CONFIG.PREFIX}تغيير_الصورة*\n` +
      `  *📌 ${CONFIG.PREFIX}تثبيت*\n` +
      `  *📜 ${CONFIG.PREFIX}القوانين*\n` +
      `  *✏️ ${CONFIG.PREFIX}تغيير_القوانين <نص>*\n` +
      `${FOOTER_DIVIDER}\n` +
      `💡 منشن الكل/قفل/فتح لها أزرار جاهزة تحت 👇\n` +
      `🛡️ زر "أوامر متقدمة": منع الكلمات/الروابط/الميديا، مضاد البوتات، طلبات الانضمام، ملخص، ستوري وغيرها`;

    // أوامر بدون أي مدخل مطلوب (منشن كل الكروب / قفل / فتح) → أزرار.
    // بقية أوامر الإشراف (طرد/حظر/كتم/ترقية...) تبقى كتابية عمدًا لأنها
    // تحتاج تحديد شخص بمنشن أو رد على رسالته، زي ما طلبت بالضبط.
    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("admin") || undefined,
      extraButtons: [buildSingleSelectButton("🛡️ أوامر متقدمة", "أوامر المشرفين المتقدمة", ADMIN_EXTRA_ROWS)],
      quickButtons: [
        sectionButton("منشن", "📢 منشن الكل"),
        sectionButton("قفل", "🔒 قفل الكتابة"),
        sectionButton("فتح", "🔓 فتح الكتابة"),
        ...navButtons(),
      ],
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
