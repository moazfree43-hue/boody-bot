import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, navButtons } from "../../utils/interactive";
import { FOOTER_DIVIDER } from "../../utils/theme";
import { getSectionImageBuffer } from "../../utils/media";
import { isOwner } from "../../middlewares/permissions";

const command: Command = {
  name: "المطور",
  aliases: ["owner", "دولير", "مطور", "مطوري"],
  category: "المطور",
  description: "عرض بطاقة معلومات مطور البوت",
  permission: "all",
  execute: async (ctx) => {
    const vcard =
      "BEGIN:VCARD\n" +
      "VERSION:3.0\n" +
      `FN:${CONFIG.OWNER_NAME}\n` +
      `TEL;type=CELL;type=VOICE;waid=${CONFIG.OWNER_NUMBER}:+${CONFIG.OWNER_NUMBER}\n` +
      "END:VCARD";

    // بطاقة جهة اتصال حقيقية (رسالة واتساب مستقلة بطبيعتها، لا يمكن دمجها
    // بأي رسالة أخرى) — تسمح بحفظ رقم المطور مباشرة دون كتابته يدويًا.
    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        contacts: {
          displayName: CONFIG.OWNER_NAME,
          contacts: [{ vcard }],
        },
      },
      { quoted: ctx.msg }
    );

    const text =
      `✦ ───────── ✦\n      👑 *بطاقة المطور* 👑\n✦ ───────── ✦\n\n` +
      `  الاسم ﹘ \n 👑 𝑴𝑰𝑯𝑨𝑾𝑲 | 𒉭 ميهوك\n` +
      `  البوت ﹘ \n『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』\n\n` +
      `  💬 راسله مباشرة بالزر تحت، أو من بطاقة جهة الاتصال بالأعلى 👆\n` +
      `✦ ───────── ✦`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("developer") || undefined,
      quickButtons: navButtons(),
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });

    // قائمة أوامر المطور المرتبة — تظهر للمطور بس، حتى ما تنكشف لبقية الأعضاء
    if (isOwner(ctx.senderJid, ctx.metadata || undefined)) {
      const ownerCommandsText =
        `${FOOTER_DIVIDER}\n      🔐 *أوامر المطور* 🔐\n${FOOTER_DIVIDER}\n\n` +
        `📢 *تحكم عام:*\n` +
        `  ${CONFIG.PREFIX}اذاعة <نص> — رسالة لكل المجموعات\n` +
        `  ${CONFIG.PREFIX}وضع_عام — البوت يستجيب للجميع\n` +
        `  ${CONFIG.PREFIX}وضع_خاص — البوت يستجيب للمالك فقط\n\n` +
        `${FOOTER_DIVIDER}\n\n` +
        `🎛️ *تحكم بمجموعة محددة:*\n` +
        `  ${CONFIG.PREFIX}تشغيل — يشغّل البوت بهذي المجموعة\n` +
        `  ${CONFIG.PREFIX}ايقاف — يوقف البوت بهذي المجموعة\n` +
        `  ${CONFIG.PREFIX}رقيني — يرقّيك مشرف مباشرة\n\n` +
        `${FOOTER_DIVIDER}\n\n` +
        `🛠️ *صيانة البوت:*\n` +
        `  ${CONFIG.PREFIX}تشخيص — تقرير أسباب توقف الأوامر\n` +
        `  ${CONFIG.PREFIX}تحديث — إعادة تحميل الأوامر بدون ريستارت\n` +
        `  ${CONFIG.PREFIX}اعادة_تشغيل — إعادة تشغيل البوت بالكامل\n` +
        `  ${CONFIG.PREFIX}نسخ_احتياطي — نسخة احتياطية من قاعدة البيانات\n\n` +
        `${FOOTER_DIVIDER}`;

      await ctx.sock.sendMessage(ctx.chatId, { text: ownerCommandsText }, { quoted: ctx.msg });
    }
  },
};

export default command;
