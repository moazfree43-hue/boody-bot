import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { getGroupSettings } from "../../database/db";
import { sendButtonMessage, navButtons } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";

const onOff = (v: boolean) => (v ? "✅ مفعّل" : "❌ متوقف");

const command: Command = {
  name: "حماية",
  aliases: ["protection"],
  category: "حماية",
  description: "عرض حالة نظام الحماية في المجموعة",
  permission: "all",
  groupOnly: true,
  execute: async (ctx) => {
    const s = getGroupSettings(ctx.chatId);
    const text =
      `ـ◈▬▬ 𝑺𝑯𝑰𝑬𝑳𝑫 ▬▬◈ـ\n` +
      `▸ *الحماية العامة* ـ${onOff(s.protection)}ـ\n` +
      `▸ *ضد الروابط* ـ${onOff(s.antilink)}ـ\n` +
      `▸ *ضد السبام* ـ${onOff(s.antispam)}ـ\n` +
      `🕥 *الساعة* ـ${new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}ـ\n\n` +
      `للتحكم استخدم:\n` +
      `.اعدادات حماية تشغيل|ايقاف\n` +
      `.اعدادات روابط تشغيل|ايقاف\n` +
      `.اعدادات سبام تشغيل|ايقاف`;

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text,
      image: getSectionImageBuffer("protection") || undefined,
      quickButtons: navButtons(),
      fallbackNote: `للرجوع للقائمة الرئيسية اكتب: ${CONFIG.PREFIX}menu`,
    });
  },
};

export default command;
