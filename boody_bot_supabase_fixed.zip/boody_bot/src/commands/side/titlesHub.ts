import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, buildSingleSelectButton } from "../../utils/interactive";

/** 🆕 (طلب صريح: "اتصال نظام الألقاب") — قائمة واحدة تجمع كل أوامر الألقاب (المخزّنة بـSupabase). */
const command: Command = {
  name: "نظام_الالقاب",
  aliases: ["الالقاب_قائمة", "titles"],
  category: "اوامر_جانبيه",
  description: "قائمة كل أوامر نظام الألقاب",
  permission: "all",
  execute: async (ctx) => {
    const p = CONFIG.PREFIX;
    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text:
        `🏷️ *نظام الألقاب*\n\n` +
        `${p}تسجيل_لقب <لقب> — سجّل لقبك\n${p}تغير_لقب <لقب> — غيّر لقبك\n${p}حذف_لقب — احذف لقبك\n` +
        `${p}لقبي • ${p}لقبه @شخص — اعرف اللقب\n${p}متوفر <لقب> — هل اللقب فاضي؟\n${p}اللقاب — كل الألقاب\n` +
        `${p}حجز_لقب • ${p}حذف_الألقاب — للمشرفين`,
      mentions: [ctx.senderJid],
      quoted: ctx.msg,
      extraButtons: [
        buildSingleSelectButton("🏷️ الألقاب", "نظام الألقاب", [
          { command: "تسجيل_لقب", label: "✍️ تسجيل لقب", description: "سجّل لقبك" },
          { command: "تغير_لقب", label: "🔁 تغيير لقب", description: "غيّر لقبك" },
          { command: "حذف_لقب", label: "🗑️ حذف لقب", description: "احذف لقبك" },
          { command: "لقبي", label: "🏷️ لقبي", description: "لقبك الحالي" },
          { command: "متوفر", label: "🔍 متوفر", description: "فحص توفر لقب" },
          { command: "اللقاب", label: "📜 كل الألقاب", description: "قائمة الألقاب" },
        ]),
      ],
      fallbackNote: `اكتب الأمر مباشرة، مثال: ${p}تسجيل_لقب سلطان`,
    });
  },
};

export default command;
