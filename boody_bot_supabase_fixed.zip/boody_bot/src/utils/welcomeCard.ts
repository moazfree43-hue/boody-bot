/**
 * يبني نص بطاقة الترحيب الموحّد (يُستخدم بأمر .ترحيب اليدوي وبالترحيب
 * التلقائي عند دخول عضو جديد) — نفس الستايل بمكان وحد بدل تكراره بملفين.
 */
export function buildWelcomeCard(groupName: string, mention: string, customLine?: string): string {
  const line = customLine?.trim();
  const extra = line ? `\n✦ *${line}*` : "";
  return (
    `╮─❀─────────╭\n` +
    `ـ˖° 𝑾𝑬𝑳𝑪𝑶𝑴𝑬 °˖ـ\n` +
    `╯─────────❀─╰\n` +
    `✦ *أهلاً بك* ـ${mention}ـ\n` +
    `✦ *بمجموعة* ـ${groupName}ـ${extra}\n` +
    `🕥 *الساعة* ـ${new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}ـ\n` +
    `📅 *التاريخ* ـ${new Date().toLocaleDateString("ar-EG")}ـ\n\n` +
    `  _🌿 نورت الجو_`
  );
}

/**
 * 🆕 يبني نص بطاقة الوداع (تُرسل مع صورة بروفايل العضو المغادر، نفس فكرة
 * بطاقة الترحيب بالضبط) — قالب محدد بطلب صريح.
 */
export function buildGoodbyeCard(groupName: string, mention: string): string {
  return (
    `*${groupName}*\n` +
    `${mention}\n` +
    `*اذاً فنهايه اخترت ان ترحل*\n` +
    `*صحيح!*\n` +
    `__________•♡•____________\n` +
    `*حسنا نتمنا لك اتوفيق في* \n` +
    `*احلامك وهدافك🖤*\n` +
    `ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n` +
    `*ولا تنسا*\n` +
    `*ان اللهﷻ معك  داىما*\n` +
    `*ولا ترجو غيره* \n\n` +
    `*『 𝑩𝑶𝑶𝑫𝒀 ┆ 🌑 ┆ 𝑩𝑶𝑻 』*`
  );
}
